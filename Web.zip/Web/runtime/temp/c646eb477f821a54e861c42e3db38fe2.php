<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:67:"D:\Web\wamp64\www\tp5\public/../application/index\view\top\top.html";i:1527769693;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body>
13213
</body>
</html>
