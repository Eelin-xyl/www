<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:75:"D:\Web\wamp64\www\tp5\public/../application/index\view\shop\MrZhu\bags.html";i:1529907677;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body>
<table width="100%" >
  <tr>
    <td rowspan="2" widtth="240" align="center">
    <a href="<?php echo url('/index/common/homepage'); ?>">
    <img src="/tp5/public/static/common/logo.jpg" width="80" height="80" />
    </a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/pi'); ?>"><?php echo $user; ?></a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/order'); ?>">我的订单</a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/addgoods'); ?>">添加商品</a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/charge'); ?>">充值中心</a></td>
  </tr>
  <tr>
    <td colspan="4" align="center">
      <input type="text" name="searchtext" size="60" />      
      <input type="submit" name="search" value="搜索"/>
    </td>
  </tr>
</table>
<table align="center">
<?php if(is_array($ginfo) || $ginfo instanceof \think\Collection || $ginfo instanceof \think\Paginator): $i = 0; $__LIST__ = $ginfo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
  <tr align="center">
    <td>
      <img src="/tp5/public/static<?php echo $vo['image']; ?>" width="300" height="400"/>
    </td>
  </tr>
  <tr align="center">
    <td>
      <?php echo $vo['name']; ?>
    </td>
  </tr>
  <tr align="center">
    <td>
      产地：<?php echo $vo['origin']; ?>
    </td>
  </tr>
  <tr align="center">
    <td>
      库存：<?php echo $vo['amount']; ?>
    </td>
  </tr>
  <tr align="center">
    <td>
      <a href="<?php echo url('/index/shop/shop', ['sid' => $vo['uid']]); ?>"><?php echo $vo['sname']; ?></a>
    </td>
  </tr>
  <tr align="right">
    <td>
     <input type="button" value="加入购物车" name="addcart" />
    </td>
  </tr>
<?php endforeach; endif; else: echo "" ;endif; ?>
</table>

</body>
</html>