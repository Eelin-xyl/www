<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:73:"D:\Web\wamp64\www\tp5\public/../application/index\view\common\charge.html";i:1529568309;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body>
<table width="100%" >
  <tr>
    <td width="20%" align="center">
    <a href="<?php echo url('/index/common/homepage'); ?>">
    <img src="/tp5/public/static/common/logo.jpg" width="80" height="80" />
    </a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/pi'); ?>">个人信息</a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/order'); ?>">我的订单</a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/addgoods'); ?>">添加商品</a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/charge'); ?>">充值中心</a></td>
  </tr>
</table>
<h1 align="center">充值中心</h1>
<form method="post" action="<?php echo url('/index/account/charge'); ?>">
<table align="center">
  <tr>
    <td>当前余额：￥</td>
  </tr>
  <tr>
    <td><?php echo $money; ?></td>
  </tr>
  <tr>
    <td>充值金额：￥</td>
  </tr>
  <tr>
    <td><input type="text" name="money" /></td>
  </tr>
  <tr>
    <td><input type="submit" value="确认" /></td>
  </tr>
</table>
</form>
</body>
</html>