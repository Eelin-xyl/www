<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:75:"D:\Web\wamp64\www\tp5\public/../application/index\view\common\homepage.html";i:1529510565;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body>
<table width="100%" >
  <tr>
    <td rowspan="2" widtth="240" align="center">
    <a href="<?php echo url('/index/common/homepage'); ?>">
    <img src="/tp5/public/static/common/logo.jpg" width="80" height="80" />
    </a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/pi'); ?>"><?php echo $user; ?></a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/order'); ?>">我的订单</a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/addgoods'); ?>">添加商品</a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/charge'); ?>">充值中心</a></td>
  </tr>
  <tr>
    <td colspan="3" align="center">
        <h1><em><strong>澳门首家</strong></em>     
          <input type="text" name="searchtext" size="60" />      
          <input type="submit" name="search" value="搜索"/>
        </h1>
    </td>
    <td align="left">
      <a href="<?php echo url('/index/common/shopcart'); ?>">
        <img src="/tp5/public/static/common/shopcart.png" width="40" height="40"/>
      </a>
    </td>
  </tr>
  <tr height="80">
    <td align="center"><a href="<?php echo url('/index/category/computers'); ?>">
    手机电脑
    </a></td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
  </tr>
  <tr height="80">
    <td align="center"><a href="<?php echo url('/index/category/clothes'); ?>">
    男装女装
    </a></td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
  </tr>
  <tr height="80">    
    <td align="center"><a href="<?php echo url('/index/category/bags'); ?>">
    箱包户外
    </a></td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
  </tr>
  <tr height="80">    
    <td align="center"><a href="<?php echo url('/index/category/books'); ?>">
    图书音像
    </a></td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
  </tr>
</table>
</body>
</html>
