<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:77:"D:\Web\wamp64\www\tp5\public/../application/index\view\homepage\homepage.html";i:1528359280;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body>
<table width="100%" >
  <tr>
    <td rowspan="2" widtth="240" align="center">
    <a href="<?php echo url('/index/index/homepage'); ?>">
    <img src="/tp5/public/static/index/飞船.jpg" width="80" height="80" />
    </a></td>
    <td widtth="240" align="center"><a href="登录.php">登陆</a></td>
    <td widtth="240" align="center"><a href="订单.php">我的订单</a></td>
    <td widtth="240" align="center"><a href="修改资料.php">我的京东</a></td>
    <td widtth="240" align="center"><a href="客服.php">客户服务</a></td>
  </tr>
  <tr>
    <td colspan="3" align="center">
        <h1><em><strong>澳门首家</strong></em>     
          <input type="text" name="searchtext" size="60" />      
          <input type="submit" name="search" value="搜索"/>
        </h1>
    </td>
    <td align="left">
      <img src="/tp5/public/static/index/购物车.png" width="40" height="40"/>
    </td>
  </tr>
  <tr height="80">
    <td align="center"><a href="手机电脑/手机电脑.php">手机电脑</a></td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
  </tr>
  <tr height="80">
    <td align="center"><a href="男装女装/男装女装.php">男装女装</a></td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
  </tr>
  <tr height="80">    
    <td align="center"><a href="箱包户外/箱包户外.php">箱包户外</a></td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
  </tr>
  <tr height="80">    
    <td align="center"><a href="图书音像/图书音像.php">图书音像</a></td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
  </tr>
</table>

</body>
</html>
