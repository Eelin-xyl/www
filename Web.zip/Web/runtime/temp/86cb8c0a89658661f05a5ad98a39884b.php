<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:78:"D:\Web\wamp64\www\tp5\public/../application/index\view\shop\MrZhu\clothes.html";i:1529510806;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body>
<table width="100%" >
  <tr>
    <td rowspan="2" widtth="240" align="center">
    <a href="<?php echo url('/index/common/homepage'); ?>">
    <img src="/tp5/public/static/common/logo.jpg" width="80" height="80" />
    </a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/pi'); ?>"><?php echo $user; ?></a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/order'); ?>">我的订单</a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/addgoods'); ?>">添加商品</a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/charge'); ?>">充值中心</a></td>
  </tr>
  <tr>
    <td colspan="4" align="center">
      <input type="text" name="searchtext" size="60" />      
      <input type="submit" name="search" value="搜索"/>
    </td>
  </tr>
</table>
<table width="100%">
<tr><td>
<div align="center">
<img src="/tp5/public/static/shop/MrZhu/clothes.jpg" width="300" height="400"/>
</div>
</td></tr>
<tr align="center"><td>
产地四川。。。。。。
</td></tr>
<tr align="center"><td><a href="<?php echo url('/index/shop/MrZhu'); ?>">
店铺：朱老师的店铺
</a></td></tr>
<tr align="center"><td>
<input type="button" value="加入购物车" name="addcart" />
</td></tr>
</table>
</body>
</html>