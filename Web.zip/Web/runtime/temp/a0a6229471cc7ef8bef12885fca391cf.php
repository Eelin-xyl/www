<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"D:\Web\wamp64\www\tp5\public/../application/index\view\common\service.html";i:1529465383;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body>
<table width="100%" >
  <tr>
    <td width="20%" align="center">
    <a href="<?php echo url('/index/common/homepage'); ?>">
    <img src="/tp5/public/static/common/logo.jpg" width="80" height="80" />
    </a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/pi'); ?>">个人资料</a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/order'); ?>">我的订单</a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/addgoods'); ?>">添加商品</a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/service'); ?>">客户服务</a></td>
  </tr>
</table>
<h1>很抱歉还没有请客服！
</h1>
</body>
</html>