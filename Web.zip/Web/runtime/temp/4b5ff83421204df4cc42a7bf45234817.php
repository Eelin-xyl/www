<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:69:"D:\Web\wamp64\www\tp5\public/../application/index\view\common\pi.html";i:1530523046;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body>
<table width="100%" >
  <tr>
    <td width="20%" align="center">
    <a href="<?php echo url('/index/common/homepage'); ?>">
    <img src="/tp5/public/static/common/logo.jpg" width="80" height="80" />
    </a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/pi'); ?>">个人信息</a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/order'); ?>">我的订单</a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/addgoods'); ?>">添加商品</a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/charge'); ?>">充值中心</a></td>
  </tr>
</table>
<a href="<?php echo url('/index/account/logout'); ?>">
<button>退出登录</button></a>

<h1 align="center">个人资料</h1>
<table align="center">
<?php if(is_array($info) || $info instanceof \think\Collection || $info instanceof \think\Paginator): $i = 0; $__LIST__ = $info;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
  <tr>
    <td>账号：<?php echo $uid; ?></td>
  </tr>
  <tr>
  <td>昵称：<?php echo $vo['nickname']; ?></td>
  </tr>
  <tr>
    <td>密码：<?php echo $vo['password']; ?></td>
  </tr>
  <tr>
    <td>余额：￥<?php echo $vo['money']; ?></td>
  </tr>
  <tr>
    <td>地址：<?php echo $vo['origin']; ?></td>
  </tr>
  <tr>
    <td>账户创建时间：<?php echo $regtime = date('Y-m-d H:i:s', $vo['regtime']); ?></td>
  </tr>
<?php endforeach; endif; else: echo "" ;endif; ?>
</table>

<h1 align="center">个人商品</h1>
<table align="center">
<tr>
<?php if(is_array($ginfo) || $ginfo instanceof \think\Collection || $ginfo instanceof \think\Paginator): $i = 0; $__LIST__ = $ginfo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<td>
  <table>
    <tr align="center">
      <td><a href="<?php echo url('/index/shop/goods', ['gid' => $vo['gid']]); ?>">
          <img src="/tp5/public/static<?php echo $vo['image']; ?>" width="150" height="200" />
      </a></td>
    </tr>
    <tr align="center">
      <td><?php echo $vo['name']; ?></td>
    </tr>
    <tr align="center">
      <td>价格：￥<?php echo $vo['price']; ?></td>
    </tr>
    <tr align="center">
      <td>库存：<?php echo $vo['amount']; ?></td>
    </tr>
  </table>
</td>
<?php endforeach; endif; else: echo "" ;endif; ?>
</tr>
</table>

</body>
</html>