<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:75:"D:\Web\wamp64\www\Web\public/../application/index\view\common\register.html";i:1529510806;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body>
<table width="100%" >
  <tr>
    <td width="20%" align="center">
    <a href="<?php echo url('/index/common/homepage'); ?>">
    <img src="/Web/public/static/common/logo.jpg" width="80" height="80" />
    </a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/login'); ?>">登陆</a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/order'); ?>">我的订单</a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/pi'); ?>">我的资料</a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/charge'); ?>">充值中心</a></td>
  </tr>
</table>
<h1 align="center">注册</h1>
<form method="post" action="<?php echo url('/index/account/register'); ?>">
<table align="center" >
      <tr><td>
             账号
      </td></tr>
      <tr><td>
             <input type="text" name="uid" />
      </td></tr>
      <tr><td>
             密码
      </td></tr>
      <tr><td>
             <input type="password" name="password" />    
      </td></tr>
      <tr><td>
             确认密码
      </td></tr>
      <tr><td>
             <input type="password" name="repassword" /> 
      </td></tr>      
      <tr><td>
             昵称
      </td></tr>
      <tr><td>
             <input type="text" name="nickname" />
      </td></tr>
      <tr><td>
             地址
      </td></tr>
      <tr><td>
             <input type="text" name="origin" />
      </td></tr>
      <tr><td>
             <input name="submit" type="submit" value="提交"/>
      </td></tr>
</table>
</form>
</body>
</html>