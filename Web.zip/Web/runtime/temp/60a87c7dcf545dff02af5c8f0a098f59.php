<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:72:"D:\Web\wamp64\www\Web\public/../application/index\view\common\order.html";i:1583320283;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body>
<table width="100%" >
  <tr>
    <td width="20%" align="center">
    <a href="<?php echo url('/index/common/homepage'); ?>">
    <img src="/Web/public/static/common/logo.jpg" width="80" height="80" />
    </a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/pi'); ?>">个人信息</a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/order'); ?>">我的订单</a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/addgoods'); ?>">添加商品</a></td>
    <td widtth="240" align="center"><a href="<?php echo url('/index/common/charge'); ?>">充值中心</a></td>
  </tr>
</table>

<table  align="center" width="90%">
<tr>
  <th>订单编号</th>
  <th colspan="3">
    订单详情
  </th>
  <th>
    金额
  </th>
  <th>
    状态
  </th>
  <th>
    操作
  </th>
  <th>
    评价
  </th>
</tr>
<tr height="20px"></tr>
<?php if(is_array($oinfo) || $oinfo instanceof \think\Collection || $oinfo instanceof \think\Paginator): $i = 0; $__LIST__ = $oinfo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<tr>
  <td></td>
  <td colspan="3" align="center">
    <?php echo $time = date('Y-m-d H:i:s', $vo['time']); ?>
  </td>
</tr>
<tr align="center">
  <td width="10%"><?php echo $vo['oid']; ?></td>
  <td width="10%">
    <a href="<?php echo url('/index/shop/goods', ['gid' => $vo['gid']]); ?>">
      <img src="/Web/public/static<?php echo $vo['image']; ?>" width="90" height="120" />
    </a>
  </td>
  <td width="5%">
    <div align="left"><?php echo $vo['name']; ?></div></td>  
  <td width="5%">
    <div align="left">X <?php echo $vo['number']; ?></div></td> 
  <td width="10%">
    <?php echo $vo['total']; ?>
  </td>
  <form action="<?php echo url('/index/common/rebuy', (['oid' => $vo['oid']])); ?>">
  <td width="10%">
    <?php echo $vo['status']; ?>
  </td>
  </form>
  <td width="10%">
    <button>确认收货</button>
  </td>
  <form action="<?php echo url('/index/common/gocomment', (['oid' => $vo['oid']])); ?>">
  <td width="10%">
    <?php echo $vo['comment']; ?>
  </td>
  </form>
</tr>
<tr height="10px"></tr>
<?php endforeach; endif; else: echo "" ;endif; ?>
</table>

</body>
</html>