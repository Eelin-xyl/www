<?php
$servername = "10.7.126.15";
$dbusername = "Yilin.Xue20";
$dbpassword = "duo5123";
$dbname = "yilin.xue20";

$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
